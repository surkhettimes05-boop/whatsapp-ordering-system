export { _ as default } from "../esm/_class_extract_field_descriptor.js";
