export { _ as default } from "../esm/_class_static_private_field_destructure.js";
