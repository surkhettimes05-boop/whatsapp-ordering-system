export { _ as default } from "../esm/_throw.js";
