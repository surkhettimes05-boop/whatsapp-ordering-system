export declare function joinPathSegments(a: string, b: string, separator: string): string;
