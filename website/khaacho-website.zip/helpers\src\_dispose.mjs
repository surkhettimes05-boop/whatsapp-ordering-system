export { _ as default } from "../esm/_dispose.js";
