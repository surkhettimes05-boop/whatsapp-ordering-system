export { _ as default } from "../esm/_object_spread.js";
