export {};
//# sourceMappingURL=modern-module-resolution.d.ts.map