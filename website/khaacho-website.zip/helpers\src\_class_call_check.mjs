export { _ as default } from "../esm/_class_call_check.js";
