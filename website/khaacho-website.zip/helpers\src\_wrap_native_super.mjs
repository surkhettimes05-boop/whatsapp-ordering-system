export { _ as default } from "../esm/_wrap_native_super.js";
