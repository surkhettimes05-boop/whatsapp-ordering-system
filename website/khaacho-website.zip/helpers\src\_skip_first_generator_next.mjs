export { _ as default } from "../esm/_skip_first_generator_next.js";
