export declare function pruneAsync(): Promise<void>;
//# sourceMappingURL=prune.d.ts.map