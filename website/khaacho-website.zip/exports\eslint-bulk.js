"use strict";
// Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
// See LICENSE in the project root for license information.
Object.defineProperty(exports, "__esModule", { value: true });
// "lib/exports/eslint-bulk" is the entry point for the @rushstack/eslint-bulk command line front end.
require("../eslint-bulk-suppressions/cli/start");
//# sourceMappingURL=eslint-bulk.js.map