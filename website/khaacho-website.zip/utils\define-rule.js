"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "defineRule", {
    enumerable: true,
    get: function() {
        return defineRule;
    }
});
var defineRule = function(rule) {
    return rule;
};
