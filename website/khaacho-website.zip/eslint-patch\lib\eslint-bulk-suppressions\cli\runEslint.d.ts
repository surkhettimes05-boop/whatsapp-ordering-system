export declare function runEslintAsync(files: string[], mode: 'suppress' | 'prune'): Promise<void>;
//# sourceMappingURL=runEslint.d.ts.map