export declare function isCorrectCwd(cwd: string): boolean;
//# sourceMappingURL=is-correct-cwd.d.ts.map